/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.gestaovarejo.test;

import br.com.gestaovarejo.business.LoginBusiness;
import br.com.gestaovarejo.business.interfaces.LoginInterface;
import br.com.gestaovarejo.dominio.Cliente;
import br.com.gestaovarejo.dominio.Fornecedor;
import br.com.gestaovarejo.dominio.Usuario;

/**
 *
 * @author internet
 */
public class LoginPolimorfismoMock {
    
    public static void main(String agrs[]){
        Usuario novoUsuario = new Usuario();
        novoUsuario.setLogin("Wakanda SA");
        novoUsuario.setSenha("wakanda1234");

        Usuario novoUsuario2 = new Usuario();
        novoUsuario2.setLogin("Tony");
        novoUsuario2.setSenha("vingadores123");

        LoginBusinessMock.gerarClienteMock();
        LoginBusinessMock.gerarFornecedorMock();
        
        
        
        LoginInterface loginBusiness = new LoginBusiness();
        
        Usuario usuario = loginBusiness.validarUsuario(novoUsuario);
        Usuario usuario2 = loginBusiness.validarUsuario(novoUsuario2);

        
        System.out.println("Finalizamos");
    }
            
}


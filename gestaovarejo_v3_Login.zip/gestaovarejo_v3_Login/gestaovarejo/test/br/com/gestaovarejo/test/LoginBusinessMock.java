/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.gestaovarejo.test;

import br.com.gestaovarejo.business.LoginBusiness;
import br.com.gestaovarejo.business.interfaces.LoginInterface;
import br.com.gestaovarejo.dominio.Cliente;
import br.com.gestaovarejo.dominio.Endereco;
import br.com.gestaovarejo.dominio.Fornecedor;
import br.com.gestaovarejo.dominio.Produto;
import br.com.gestaovarejo.repositorio.Repositorio;
import java.util.ArrayList;
import java.util.List;

/**
 *
 * @author internet
 */
public class LoginBusinessMock {
    
    public static Fornecedor gerarFornecedorMock(){
        Fornecedor fornecedor = new Fornecedor();
        fornecedor.setNome("Wakanda SA");
        
        fornecedor.setLogin("Wakanda SA");
        fornecedor.setSenha("wakanda1234");
        
        
        Endereco endereco = new Endereco();
        endereco.setBairro("Wakanda");
        endereco.setCep(0);
        endereco.setCidade("Wakanda");
        endereco.setComplemento("44st");
        endereco.setEstado("Wakanda");
        endereco.setMundo("Earth");
        endereco.setNumero(0);
        endereco.setPais("Wakanda");
        endereco.setRua("0");
        
        fornecedor.setEndereco(endereco);

        List<String> emails = new ArrayList<String>();
        emails.add("tchala@wakanda.org");
        emails.add("blackpanter@vingadores.org");
        
        fornecedor.setEmails(emails);
        
        List<Integer> telefones = new ArrayList<Integer>();
        telefones.add(321654);
        telefones.add(123456);

        fornecedor.setTelefones(telefones);
        Repositorio.fornecedorDBFake.add(fornecedor);    
        return fornecedor;
    }
    
    public static Produto gerarProdutoMock(){
        Produto produto = new Produto();
        
        produto.setFabricante("Wakanda SA");
        produto.setNomeProduto("Vibranio");
        produto.setValidade("10/10/2010");
        
        return produto;
    }
    
    
    public static Cliente gerarClienteMock(){
        Cliente novoCliente = new Cliente();
        
        novoCliente.setNome("Tony");
        novoCliente.setSobrenome("Stark");
        novoCliente.setLogin("Tony");
        novoCliente.setSenha("vingadores123");
        
        Endereco endereco = new Endereco();
        endereco.setBairro("Manhattan");
        endereco.setCep(245987);
        endereco.setCidade("New York");
        endereco.setComplemento("44st");
        endereco.setEstado("New York");
        endereco.setMundo("Earth");
        endereco.setNumero(235);
        endereco.setPais("USA");
        endereco.setRua("44st");
        
        novoCliente.setEndereco(endereco);
        
        List<String> emails = new ArrayList<String>();
        emails.add("ts@starkcompany.org");
        emails.add("homemdeferro@vingadores.org");
        
        novoCliente.setEmails(emails);
        
        List<Integer> telefones = new ArrayList<Integer>();
        telefones.add(123456);
        telefones.add(654321);
        
        novoCliente.setTelefones(telefones);
        Repositorio.clienteDBFake.add(novoCliente);
        return novoCliente;
    }
    
    public static void main(String agrs[]){
        LoginInterface loginBusiness = new LoginBusiness();
        
        Cliente cliente = gerarClienteMock();
        Fornecedor fornecedor = gerarFornecedorMock();
        Produto produto = gerarProdutoMock();
        
        List<Produto> produtos = new ArrayList<Produto>();
        produtos.add(produto);
        fornecedor.setProdutosFornecidos(produtos);
        
    }    
}



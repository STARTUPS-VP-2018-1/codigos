/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package br.com.gestaovarejo.business;

import br.com.gestaovarejo.business.interfaces.LoginInterface;
import br.com.gestaovarejo.dominio.Cliente;
import br.com.gestaovarejo.dominio.Fornecedor;
import br.com.gestaovarejo.dominio.Usuario;
import br.com.gestaovarejo.repositorio.Repositorio;

/**
 *
 * @author internet
 */
public class LoginBusiness implements LoginInterface{

    @Override
    public Cliente validarUsuario(Cliente cliente) {
        for(int i = 0; i< Repositorio.clienteDBFake.size();i++){
            Cliente clienteFake = Repositorio.clienteDBFake.get(i);
            if(clienteFake.getNome().equals(cliente.getNome())){
                return clienteFake;
            }           
        }
        return null;
    }

    @Override
    public Fornecedor validarUsuario(Fornecedor fornecedor){
        for(Fornecedor fornecedorFake: Repositorio.fornecedorDBFake){
            if(fornecedorFake.getNome().equals(fornecedor.getNome())){
                return fornecedorFake;
            }
        }
        return null;
    }

    @Override
    public Usuario validarUsuario(Usuario usuario) {
        for(Fornecedor fornecedorFake: Repositorio.fornecedorDBFake){
            if(fornecedorFake.getLogin().equals(usuario.getLogin())){
                return fornecedorFake;
            }
        }
        
        for(Cliente clienteFake :Repositorio.clienteDBFake){
            if(clienteFake.getNome().equals(clienteFake.getNome())){
                return clienteFake;
            }   
        }
        
        return null;
    }
    
}

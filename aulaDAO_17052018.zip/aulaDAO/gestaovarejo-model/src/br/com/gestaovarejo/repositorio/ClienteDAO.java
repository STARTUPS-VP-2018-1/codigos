package br.com.gestaovarejo.repositorio;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Calendar;

import br.com.gestaovarejo.dominio.Cliente;

public class ClienteDAO {

	
    public Connection getConnection() {
        try {
            return DriverManager.getConnection(
    "jdbc:h2:./bancodedados/bancodedados.db", "sa", "");
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }
    
    
    public void inserirCliente(Cliente cliente) 
    		throws SQLException{
        Connection con = new ClienteDAO().getConnection();
        String sql = "insert into CLIENTE" +
                " (NOME,SOBRENOME)" +
                " values (?,?)";
        PreparedStatement stmt = con.prepareStatement(sql);
        stmt.setString(1, cliente.getNome());
        stmt.setString(2, cliente.getSobrenome());

        stmt.execute();
        stmt.close();   	
    }
    
    public static void main(String[] args) throws SQLException {
    	ClienteDAO clienteDAO = new ClienteDAO();
    	
    	Cliente cliente = new Cliente();
    	
    	cliente.setNome("Ricardo");
    	cliente.setSobrenome("Henrique");
    	
    	clienteDAO.inserirCliente(cliente);
    	
	}
    
    
    
    
    
    
    
    
    
}
